cd examples
rm -f public
ln -s /afs/desy.de/user/s/school00/public .
cd public/RGS

source setup.sh
cd ../..
export PATH=`pwd`/bin:$PATH
export PYTHONPATH=`pwd`/python:$PYTHONPATH
echo $PYTHONPATH

